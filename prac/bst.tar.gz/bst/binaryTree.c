
//binary tree implementation 
//peter kydd
//26/10

static TreeNode newTreeNode( int data);
static TreeNode findValue(Tree t);
static doDisposeTree

typedef struct _treeRep{
   Tree root;
   int size;
} treeRep;


typedef struct treeNodeRep{
   int data;
   int size;
   TreeNode left;
   TreeNode right
}treeNodeRep;

// creates a new node and returns poitner to that node 
static TreeNode newTreeNode( int data){
      
   TreeNode newNode = malloc(sizeof(treeNodeRep));
   newNode->left = NULL;
   newNode->right = NULL;
   newNode->data = data;
   
   return newNode;
}

// find the node containing the specified value
// return NULL if value not found;
// for use with delete node etc. 
static TreeNode findValue(Tree t){
   
   printf("NEED TO IMPLEMENT FINDVALUE.\n");
   
   return t->root;
}

static doDisposeTree(TreeNode node){
   
   if( node->left != NULL){
      doDisposeTree(node->left);
      free(node->left);
   
   }
   if(node->right != NULL){
      doDisposeTree(node->right);
      free(node->right);
   
   }
   
   //free(node);


}

Tree createTree(void){
   Tree newTree = malloc(sizeof(treeRep));
   assert(newTree != NULL);
   
   newTree->root = NULL;
   newTree->size = 1;
   
   return newTree;

}

// dispose of tree and free malloc'd memory 
void disposeTree(Tree t){
   
   if(Tree->root != NULL){
      doDisposeTree(Tree->root);
   }
   
   free(t);

}

// inserts a new node at the root of the tree
void insertAtRoot(Tree t);

// inserters a new node at a balanced position in the tree
void insertBalanced(Tree t);

//delete the node with the specified value
// if value is not discovered, print error message
void deleteNode(Tree t);

// checks to see if the tree is degenerate 
int isDegenerate(Tree t);

// prints postFix order (L R N)
void printPostFix(Tree t);
   
// prints in inFix order (L N R)
void printInFix(Tree t);

// prints in preFix order (N L R)
void printPreFix(Tree t);

// checks to see if a value is in the tree (ie, search for value)
int inTree(Tree t);

// draw the tree in a tree-like way  
void drawTree(Tree t);

// return the height of the tree
int getHeight(Tree t);

// trim the tree below a certain level
void trimTree(Tree t, int depth);

// balance the tree
void balance(Tree t);


