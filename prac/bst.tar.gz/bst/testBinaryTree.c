//test file for binary tree implementation 
//peter kydd
//26/10
